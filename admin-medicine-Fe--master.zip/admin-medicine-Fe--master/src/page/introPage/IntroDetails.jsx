const IntroDetails = () => {
  return <div>IntroDetails</div>;
};

export default IntroDetails;
