import { Outlet } from "react-router-dom";
const CategoryOulet = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default CategoryOulet;
