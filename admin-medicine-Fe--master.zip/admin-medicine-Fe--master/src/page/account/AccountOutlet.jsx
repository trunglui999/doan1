import { Outlet } from "react-router-dom";

const AccountOutlet = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default AccountOutlet;
