import { Outlet } from "react-router-dom";

const ProductOulet = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default ProductOulet;
