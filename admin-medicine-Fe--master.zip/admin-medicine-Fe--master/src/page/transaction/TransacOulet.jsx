import { Outlet } from "react-router-dom";

const TransacOulet = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default TransacOulet;
