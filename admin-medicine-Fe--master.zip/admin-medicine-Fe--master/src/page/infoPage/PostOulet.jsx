import { Outlet } from "react-router-dom";
const PostOulet = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default PostOulet;
