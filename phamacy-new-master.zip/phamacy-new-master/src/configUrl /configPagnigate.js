export const defaultLimit = {
  limit: 25,
};
