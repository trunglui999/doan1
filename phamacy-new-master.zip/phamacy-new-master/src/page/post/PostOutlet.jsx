import { Outlet } from "react-router-dom";

const PostOutlet = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default PostOutlet;
